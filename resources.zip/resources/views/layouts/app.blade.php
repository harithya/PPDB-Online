@include('layouts.partials.header')

@yield('content')

@include('layouts.partials.footer')
