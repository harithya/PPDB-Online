<nav class="navbar navbar-light navbar-expand-lg topnav-menu">

    <div class="collapse navbar-collapse" id="topnav-menu-content">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="{{ route('siswa.home.index') }}" role="button">
                    Pendaftaran
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('siswa.pembayaran.index') }}" role="button">
                    Pembayaran
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="{{ route('siswa.informasi.index') }}" role="button">
                    Informasi
                </a>
            </li>
        </ul>
    </div>
</nav>
