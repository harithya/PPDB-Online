<div class="card bg-danger">
    <div class="card-body">
        <div class="row">
            <div class="col-md-10">
                <div style="color: #f2f2f2;">
                    <h5 class="text-white mb-4">Maaf anda dinyatakan tidak lulus seleksi </h5>
                    <p>
                        Masih ada kesempatan mendaftar dan mengikuti ppdb untuk berikutnya, jangan putus asa dan tetap
                        semangat 😇😇😇
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
