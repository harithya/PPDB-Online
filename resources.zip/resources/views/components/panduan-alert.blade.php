<div class="card bg-primary">
    <div class="card-body">
        <div class="row">
            <div class="col-md-10">
                <div class="text-white-50">
                    <h5 class="text-white mb-4">Panduan Pengisian Profile</h5>
                    <p>
                        Harap segera mengisi form pendaftaran yang sudah di sediakan, ada beberapa yang
                        harus diperhatikan, diantaranya :
                    <ul>
                        <li class="mb-1">Mengisi data identitas dengan tepat</li>
                        <li class="mb-1">Melampirkan pas foto 2x3</li>
                        <li class="mb-1">Melampirkan ijazah dari sekolah sebelumnya</li>
                    </ul>
                    </p>
                </div>
            </div>
            <div class="col-2">
                <div class="mt-0">
                    <img src="{{ asset('assets/netral.svg') }}" alt="" class="img-fluid mx-auto d-block">
                </div>
            </div>
        </div>
    </div>
</div>
